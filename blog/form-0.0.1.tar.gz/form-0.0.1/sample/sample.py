from form.form import Form


class Form(object):
    pass
